package com.example.myeducainclusao

class SocialStoriesListFragment {
}