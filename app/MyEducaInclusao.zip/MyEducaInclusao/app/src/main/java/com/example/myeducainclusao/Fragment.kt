package com.example.myeducainclusao

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat

// Dentro de um Fragment ou Activity
private val requestPermissionLauncher: registerForActivityResult
    get() = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            // Permissão concedida, pode enviar notificações
        } else {
            // Permissão negada, informe o usuário
            val context = null
            val context = null
            Toast.makeText(context, "Permissão de notificação negada.", Toast.LENGTH_SHORT).show()
        }
    }

annotation class registerForActivityResult(
    val requestPermission: ActivityResultContracts.RequestPermission,
    val function: (Boolean) -> Unit
)

private fun checkAndSendNotification() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // TIRAMISU == API 33
    if (ContextCompat.checkSelfPermission(/* context = */ requireContext, /* permission = */
            Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    ) {
        SensoryAlertHelper.sendSensoryAlert(requireContext(), "Alerta!", "Lembre-se de respirar fundo.")
    } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
        // Mostrar uma UI explicando por que você precisa da permissão
        // e então chamar requestPermissionLauncher.launch(...)
        val context = null
        Toast.makeText(context, "Precisamos da permissão para enviar alertas.", Toast.LENGTH_LONG).show()
        // (Opcional) Mostrar um diálogo antes de pedir novamente
        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        // Pedir a permissão diretamente
        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
} else {
    // Para versões anteriores ao Android 13, a permissão não é necessária em tempo de execução desta forma
    SensoryAlertHelper.sendSensoryAlert(requireContext(), "Alerta!", "Lembre-se de respirar fundo.")
}

private fun shouldShowRequestPermissionRationale(string: String): Boolean {
    val todo = TODO("Not yet implemented")
}
