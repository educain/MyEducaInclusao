package com.example.myeducainclusao

import android.R
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class HomeFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var welcomeTextView: TextView
    private lateinit var logoutButton: Button
    private lateinit var routinesButton: Button
    private lateinit var communicationButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = Firebase.auth
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        welcomeTextView = view.findViewById(value = R.id.textViewWelcome)
        logoutButton = view.findViewById(R.id.buttonLogout)
        routinesButton = view.findViewById(R.id.buttonRoutines)
        communicationButton = view.findViewById(R.id.buttonCommunication)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val user = auth.currentUser
        if (user == null) {
            // Se por algum motivo o usuário não estiver logado, volta para o login
            findNavController().navigate(R.id.loginFragment) // Navega para o destino de login
            return
        }

        welcomeTextView.text = "Bem-vindo, ${user.email ?: "Usuário"}!"

        logoutButton.setOnClickListener {
            auth.signOut()
            Toast.makeText(context, "Logout realizado.", Toast.LENGTH_SHORT).show()
            // Navega de volta para o LoginFragment, limpando o back stack
            findNavController().navigate(R.id.loginFragment)
        }

        routinesButton.setOnClickListener {
            // TODO: Navegar para a tela de Rotinas
            Toast.makeText(context, "Funcionalidade de Rotinas (a implementar)", Toast.LENGTH_SHORT).show()
            // Exemplo de navegação para um futuro RoutinesFragment:
            // findNavController().navigate(R.id.action_homeFragment_to_routinesFragment)
        }
        // ...
        routinesButton.setOnClickListener {
            findNavController().androidx.compose.foundation.layout.Column {
                val navigate = navigate(R.id.action_homeFragment_to_routinesFragment)
                navigate
            }
        }
        // ...

        communicationButton.setOnClickListener {
            // TODO: Navegar para a tela de Comunicação (PECS)
            Toast.makeText(context, "Funcionalidade de Comunicação (a implementar)", Toast.LENGTH_SHORT).show()
        }
        // ...
        communicationButton.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_pecsFragment) // Crie esta ação no nav_graph
        }
        // ...
    }

    object action_homeFragment_to_pecsFragment {

    }
}

private fun HomeFragment.navigate(value: Any) {
    val todo = TODO("Not yet implemented")
}

object buttonLogout {

}

object textViewWelcome {

}

object fragment_home {

}

object action_homeFragment_to_pecsFragment {

}
