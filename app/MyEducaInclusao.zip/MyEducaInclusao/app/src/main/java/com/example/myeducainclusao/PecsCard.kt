package com.example.myeducainclusao

data class PecsCard(
    val id: String,
    val label: String, // Texto do cartão
    val imageUrl: String? = null, // Ou imageResId: Int?
    // val audioUrl: String? = null // Se tiver áudios específicos
)package com.example.myeducainclusao

data class PecsCard(
    val id: String,
    val label: String, // Texto do cartão
    val imageUrl: String? = null, // Ou imageResId: Int?
    // val audioUrl: String? = null // Se tiver áudios específicos
)