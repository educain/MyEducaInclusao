package com.example.myeducainclusao

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.ui.layout.layout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.ktx.R
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class RoutinesFragment : Fragment() {

    private lateinit var recyclerViewRoutines: RecyclerView
    private lateinit var addRoutineItemButton: FloatingActionButton
    private lateinit var routinesAdapter: RoutinesAdapter
    private val routineItemsList = mutableListOf<RoutineItem>()

    private val db = Firebase.firestore
    private val auth = Firebase.auth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_routines, container, false).also {
            recyclerViewRoutines = it.findViewById(R.id.recyclerViewRoutines)
            addRoutineItemButton = it.findViewById(R.id.buttonAddRoutineItem)
        }

        setupRecyclerView()
        loadRoutineItems()

        addRoutineItemButton.setOnClickListener {
            // TODO: Abrir um diálogo/tela para adicionar um novo item de rotina
            // Exemplo simples de adicionar um item:
            addNewRoutineItem("Nova Tarefa ${routineItemsList.size + 1}", null)
        }
        return view
    }

    private fun setupRecyclerView() {
        routinesAdapter = RoutinesAdapter(routineItemsList)
        recyclerViewRoutines.adapter = routinesAdapter
        recyclerViewRoutines.layoutManager = LinearLayoutManager(context)
    }

    private fun loadRoutineItems() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(context, "Usuário não logado.", Toast.LENGTH_SHORT).show()
            // TODO: Navegar de volta para o login ou tratar o erro
            return
        }

        // Exemplo: Coleção 'routines' e cada documento é um item de rotina para o usuário
        db.collection("users").document(currentUser.uid).collection("routineItems")
            .orderBy("order") // Ordena pela ordem definida
            .addSnapshotListener { snapshots, e -> // addSnapshotListener para atualizações em tempo real
                if (e != null) {
                    Log.w("RoutinesFragment", "Erro ao carregar itens da rotina.", e)
                    Toast.makeText(context, "Erro ao carregar rotinas.", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val items = snapshots.toObjects<RoutineItem>()
                    routineItemsList.clear()
                    routineItemsList.addAll(items)
                    routinesAdapter.notifyDataSetChanged() // Para simplificar
                    Log.d("RoutinesFragment", "Itens da rotina carregados: ${items.size}")
                }
            }
    }

    private fun addNewRoutineItem(description: String, imageUrl: String?) {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(context, "Usuário não logado para adicionar item.", Toast.LENGTH_SHORT).show()
            return
        }

        val newItem = RoutineItem(
            description = description,
            imageUrl = imageUrl,
            order = routineItemsList.size, // Ordem simples, pode ser melhorada
            userId = currentUser.uid
        )

        // Salva o novo item no Firestore
        db.collection("users").document(currentUser.uid).collection("routineItems")
            .add(newItem) // .add() gera um ID automático
            .addOnSuccessListener { documentReference ->
                Log.d("RoutinesFragment", "Item da rotina adicionado com ID: ${documentReference.id}")
                // O SnapshotListener já deve atualizar a lista
            }
            .addOnFailureListener { e ->
                Log.w("RoutinesFragment", "Erro ao adicionar item da rotina", e)
                Toast.makeText(context, "Erro ao adicionar item.", Toast.LENGTH_SHORT).show()
            }
    }
}

private fun ERROR.findViewById(value: Any): RecyclerView {
    val todo = TODO("Not yet implemented")
}
