package missing.namespace;

import android.app.Activity;

public class PecsFragment extends Activity {
}
