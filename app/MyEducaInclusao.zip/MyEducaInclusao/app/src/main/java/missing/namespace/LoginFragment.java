package missing.namespace;

import android.app.Activity;

public class LoginFragment extends Activity {
}
