package missing.namespace

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.activity.result.registerForActivityResult
import androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import com.example.myeducainclusao.SensoryAlertHelper

// Dentro de um Fragment ou Activity
private val requestPermissionLauncher =
    registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            // Permissão concedida, pode enviar notificações
        } else {
            // Permissão negada, informe o usuário
            Toast.makeText(/* context = */ context, /* text = */
                "Permissão de notificação negada.", /* duration = */
                Toast.LENGTH_SHORT).show()
        }
    }

private fun registerForActivityResult(
    permission: ActivityResultContracts.RequestPermission,
    function: (Boolean) -> Unit
) {
    TODO("Not yet implemented")
}

private fun checkAndSendNotification() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // TIRAMISU == API 33
        val value = if (ContextCompat.checkSelfPermission(
                requireContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            SensoryAlertHelper.sendSensoryAlert(
                requireContext(),
                "Alerta!",
                "Lembre-se de respirar fundo."
            )
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            // Mostrar uma UI explicando por que você precisa da permissão
            // e então chamar requestPermissionLauncher.launch(...)
            val context = null
            Toast.makeText(
                context,
                "Precisamos da permissão para enviar alertas.",
                Toast.LENGTH_LONG
            ).show()
            // (Opcional) Mostrar um diálogo antes de pedir novamente
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            // Pedir a permissão diretamente
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }]
    } else {
        // Para versões anteriores ao Android 13, a permissão não é necessária em tempo de execução desta forma
        SensoryAlertHelper.sendSensoryAlert(
            requireContext(),
            "Alerta!",
            "Lembre-se de respirar fundo."
        )
    }
}